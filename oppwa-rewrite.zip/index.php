<?php
# redirect to main
header('location: pages/copy-and-pay.php');
