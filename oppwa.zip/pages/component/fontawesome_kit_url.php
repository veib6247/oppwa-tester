<?php
  echo '<script src="https://kit.fontawesome.com/6054d090c7.js" crossorigin="anonymous"></script>'
?>